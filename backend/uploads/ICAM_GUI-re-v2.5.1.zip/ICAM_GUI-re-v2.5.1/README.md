# Introduzione

Questa applicazione è un software progettato per leggere il peso su un vassoio, gestire lo sbilanciamento, impostare il peso massimo e salvare tutti i dati rilevanti nel database. È stata sviluppata per facilitare la gestione del carico del vassoio in modo efficiente e sicuro, per ICAM S.p.A.

## Versione 2.2

- Tentativo di risoluzione del bug di scrittura nel Modbus
- Conversione da grammi a chilogrammi nell'interfaccia utente
- Miglioramenti grafici

## Versione 2.3.1

- Risolto il bug di scrittura nel Modbus
- Modificato il salvataggio dei dati nel database da grammi a chilogrammi
- Risolto il bug di apertura del menu di configurazione del database

## Versione 2.4.0

- Implementazione del salvataggio nel database di tutti i pesi delle celle e quello totale
- I pesi nel database sono ora in chilogrammi con l'aggiunta dei grammi per consentire la precisione del tipo float (15,5)


## Versione 2.5.0

- Implementazione del salvataggio nel database di tutti i pesi compreso sbilanciamento destra sinistra
    * fix lower_left
- I pesi nel database sono ora in chilogrammi con l'aggiunta dei grammi per consentire la precisione del tipo float (15,5)
    * fix flaot 

## Versione 2.5.1

- Implementazione file log 
    


**Attuale ultima versione di rilascio: v2.5.0**

# Funzionalità

1. **Lettura del peso:** L'applicazione può leggere il peso su un vassoio utilizzando una bilancia digitale. Il peso rilevato viene mostrato sullo schermo ogni volta che il vassoio è pronto per il prelievo.

2. **Sbilanciamento:** L'applicazione può impostare lo sbilanciamento del vassoio, fornendo sia visivamente sullo schermo che alla macchina il consenso o il rifiuto per il prelievo del vassoio.

3. **Peso massimo:** L'applicazione consente di impostare un valore di peso massimo per il vassoio, che può essere utilizzato per monitorare la quantità di merci caricata. Se il peso rilevato supera il valore massimo impostato, l'applicazione visualizza un avviso.

4. **Salvataggio nel database:** Dopo ogni passaggio del vassoio, vengono salvati nel database i seguenti dati: peso dell'angolo destro in alto, angolo sinistro in alto, angolo destro in basso, angolo sinistro in basso e il peso totale del vassoio.

# Installazione 

Necessario lanciare il programma ICAM-GUI_V2.4.exe che installerá nel pc l'applicativo.